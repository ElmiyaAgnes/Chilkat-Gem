
require 'rubygems'
require 'chilkat'

mailman = Chilkat::CkMailMan.new()
print mailman.version() + "\n"


